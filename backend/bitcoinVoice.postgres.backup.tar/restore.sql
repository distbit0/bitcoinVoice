--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = public, pg_catalog;

ALTER TABLE ONLY public."publicLabelOutput" DROP CONSTRAINT "chainIDkey";
ALTER TABLE ONLY public."blockInfo" DROP CONSTRAINT "chainIDKey";
DROP INDEX public."unitsCodeIndex";
DROP INDEX public."fki_chainIDkey";
DROP INDEX public."fki_chainIDKey";
DROP INDEX public."chainPrimaryIndex";
DROP INDEX public."chUnixtimeCreated";
DROP INDEX public."chUnittimeSpentWithTxSeq";
DROP INDEX public."chOutpointsWithUnixtimeSpent";
DROP INDEX public."chLabelDate2";
DROP INDEX public."chLabelDate";
DROP INDEX public."chBlockHeightCreated";
DROP INDEX public."blockhashKey";
DROP INDEX public."blockInfoID";
DROP INDEX public."YYYchLabelDate";
DROP INDEX public."XXXunixTimeCreated";
DROP INDEX public."XXXlabelDate";
ALTER TABLE ONLY public.blockchain DROP CONSTRAINT "chainPrimaryKey";
ALTER TABLE ONLY public."publicLabelOutput" DROP CONSTRAINT "chTxIDSeq";
ALTER TABLE ONLY public."blockInfo" DROP CONSTRAINT "PrimaryKey_blockInfoID";
DROP TABLE public."publicLabelOutput";
DROP TABLE public.blockchain;
DROP TABLE public."blockInfo";
DROP EXTENSION plpgsql;
DROP SCHEMA public;
--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = public, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: blockInfo; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE "blockInfo" (
    "blockInfoID" uuid NOT NULL,
    blockhash character varying(200),
    "unixTimeLastScan" bigint,
    "chainID" bigint,
    "countOutputsWithPublicLabels" bigint,
    "countOutputsWithErrors" bigint,
    "countOutputsWithSpentPublicLabels" bigint,
    "lastErrorTxID" character varying(200)
);


ALTER TABLE "blockInfo" OWNER TO postgres;

--
-- Name: COLUMN "blockInfo"."lastErrorTxID"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "blockInfo"."lastErrorTxID" IS '	';


--
-- Name: blockchain; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE blockchain (
    "chainID" bigint NOT NULL,
    "chainName" character varying(100),
    rpcport character varying(10),
    "pathToBlockchain" character varying(200),
    "unitsCode" character varying(10),
    online boolean,
    "latestCheckedBlockHeight" bigint
);


ALTER TABLE blockchain OWNER TO postgres;

--
-- Name: COLUMN blockchain."latestCheckedBlockHeight"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN blockchain."latestCheckedBlockHeight" IS 'This is the latest height that has been scanned for public label outputs. ';


--
-- Name: publicLabelOutput; Type: TABLE; Schema: public; Owner: postgres; Tablespace: 
--

CREATE TABLE "publicLabelOutput" (
    "txID" character varying(200) NOT NULL,
    "publicLabel" character varying(200),
    "unixTimeCreated" bigint,
    "txOutputSequence" bigint NOT NULL,
    "plBlockHeightCreated" bigint,
    "amountInSatoshis" bigint,
    "unixTimeSpent" bigint DEFAULT 0 NOT NULL,
    "chainID" bigint NOT NULL
);


ALTER TABLE "publicLabelOutput" OWNER TO postgres;

--
-- Name: COLUMN "publicLabelOutput"."unixTimeCreated"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "publicLabelOutput"."unixTimeCreated" IS 'Seconds since January 1st, 1970   at 00:00 UTC.';


--
-- Name: COLUMN "publicLabelOutput"."plBlockHeightCreated"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "publicLabelOutput"."plBlockHeightCreated" IS 'Height of the block that created this PL Tx.';


--
-- Name: COLUMN "publicLabelOutput"."unixTimeSpent"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON COLUMN "publicLabelOutput"."unixTimeSpent" IS 'Time of the block that eventually spent this PL.
Note - this means this PL record no-longer counts toward the vote total - because it is now spent. 
Note - value of zero equates to unspent status (and therefore it still counts towards the PL vote.)';


--
-- Data for Name: blockInfo; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "blockInfo" ("blockInfoID", blockhash, "unixTimeLastScan", "chainID", "countOutputsWithPublicLabels", "countOutputsWithErrors", "countOutputsWithSpentPublicLabels", "lastErrorTxID") FROM stdin;
\.
COPY "blockInfo" ("blockInfoID", blockhash, "unixTimeLastScan", "chainID", "countOutputsWithPublicLabels", "countOutputsWithErrors", "countOutputsWithSpentPublicLabels", "lastErrorTxID") FROM '$$PATH$$/2060.dat';

--
-- Data for Name: blockchain; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY blockchain ("chainID", "chainName", rpcport, "pathToBlockchain", "unitsCode", online, "latestCheckedBlockHeight") FROM stdin;
\.
COPY blockchain ("chainID", "chainName", rpcport, "pathToBlockchain", "unitsCode", online, "latestCheckedBlockHeight") FROM '$$PATH$$/2059.dat';

--
-- Data for Name: publicLabelOutput; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY "publicLabelOutput" ("txID", "publicLabel", "unixTimeCreated", "txOutputSequence", "plBlockHeightCreated", "amountInSatoshis", "unixTimeSpent", "chainID") FROM stdin;
\.
COPY "publicLabelOutput" ("txID", "publicLabel", "unixTimeCreated", "txOutputSequence", "plBlockHeightCreated", "amountInSatoshis", "unixTimeSpent", "chainID") FROM '$$PATH$$/2058.dat';

--
-- Name: PrimaryKey_blockInfoID; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY "blockInfo"
    ADD CONSTRAINT "PrimaryKey_blockInfoID" PRIMARY KEY ("blockInfoID");


--
-- Name: chTxIDSeq; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY "publicLabelOutput"
    ADD CONSTRAINT "chTxIDSeq" PRIMARY KEY ("chainID", "txID", "txOutputSequence", "unixTimeSpent");


--
-- Name: chainPrimaryKey; Type: CONSTRAINT; Schema: public; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY blockchain
    ADD CONSTRAINT "chainPrimaryKey" PRIMARY KEY ("chainID");


--
-- Name: XXXlabelDate; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX "XXXlabelDate" ON "publicLabelOutput" USING btree ("publicLabel", "unixTimeCreated");


--
-- Name: XXXunixTimeCreated; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX "XXXunixTimeCreated" ON "publicLabelOutput" USING btree ("unixTimeCreated");


--
-- Name: INDEX "XXXunixTimeCreated"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON INDEX "XXXunixTimeCreated" IS 'IS THIS INDEX REQUIRED?
WHAT IS IT USED FOR?
(perhaps it is used on scanner startup to find the latest blockHeight processed???)
';


--
-- Name: YYYchLabelDate; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX "YYYchLabelDate" ON "publicLabelOutput" USING btree ("chainID", "unixTimeCreated");


--
-- Name: blockInfoID; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX "blockInfoID" ON "blockInfo" USING btree ("blockInfoID");


--
-- Name: blockhashKey; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX "blockhashKey" ON "blockInfo" USING btree ("chainID", blockhash);


--
-- Name: chBlockHeightCreated; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX "chBlockHeightCreated" ON "publicLabelOutput" USING btree ("chainID", "plBlockHeightCreated");


--
-- Name: chLabelDate; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX "chLabelDate" ON "publicLabelOutput" USING btree ("chainID", "publicLabel", "unixTimeSpent", "unixTimeCreated");


--
-- Name: INDEX "chLabelDate"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON INDEX "chLabelDate" IS 'Typically, this index is used to efficiently find records for a given label WHERE SPENT = 0 (unspent)';


--
-- Name: chLabelDate2; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX "chLabelDate2" ON "publicLabelOutput" USING btree ("chainID", "unixTimeSpent", "publicLabel", "unixTimeCreated");


--
-- Name: INDEX "chLabelDate2"; Type: COMMENT; Schema: public; Owner: postgres
--

COMMENT ON INDEX "chLabelDate2" IS 'Similar to chLabelDate - but use UNSPENT = 0 to search first';


--
-- Name: chOutpointsWithUnixtimeSpent; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX "chOutpointsWithUnixtimeSpent" ON "publicLabelOutput" USING btree ("chainID", "txID", "txOutputSequence", "unixTimeSpent");


--
-- Name: chUnittimeSpentWithTxSeq; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX "chUnittimeSpentWithTxSeq" ON "publicLabelOutput" USING btree ("chainID", "unixTimeSpent", "txID", "txOutputSequence");


--
-- Name: chUnixtimeCreated; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX "chUnixtimeCreated" ON "publicLabelOutput" USING btree ("chainID", "unixTimeCreated");


--
-- Name: chainPrimaryIndex; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE UNIQUE INDEX "chainPrimaryIndex" ON blockchain USING btree ("chainID");


--
-- Name: fki_chainIDKey; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX "fki_chainIDKey" ON "blockInfo" USING btree ("chainID");


--
-- Name: fki_chainIDkey; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX "fki_chainIDkey" ON "publicLabelOutput" USING btree ("chainID");


--
-- Name: unitsCodeIndex; Type: INDEX; Schema: public; Owner: postgres; Tablespace: 
--

CREATE INDEX "unitsCodeIndex" ON blockchain USING btree ("unitsCode");


--
-- Name: chainIDKey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "blockInfo"
    ADD CONSTRAINT "chainIDKey" FOREIGN KEY ("chainID") REFERENCES blockchain("chainID");


--
-- Name: chainIDkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY "publicLabelOutput"
    ADD CONSTRAINT "chainIDkey" FOREIGN KEY ("chainID") REFERENCES blockchain("chainID");


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

